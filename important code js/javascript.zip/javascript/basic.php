<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>javascript Demo</title>
	</head>
	<body>
		
	</body>
	<script type="text/javascript">
      var a = 5;
      var b = 9;
      console.log("addition is ", a+b);  //debugging unit testing

      var a = "hello";
      var b = " user";
      console.log(a+b) //concatenation

      console.log(2+" user"); //string

      var a="4.4";
      var b= "3.3"; //data type string
      console.log(a+b) //concatenation
      console.log("Addition of Int ", parseInt(a)+parseInt(b)) //parseInt convert string to int
      console.log("Addition of Float", parseFloat(a)+parseFloat(b)) //parseFloat convert string to float

      var msg = "Welcome user"; //string 
      var ar = ['a', 'b', 'c']; //Array
      console.log(ar)
      console.log(ar[0])
    
     r = Math.random(); //range of random number 0-1
     console.log(r)

     singleRandomNumber = Math.random()*10000;
     console.log(parseInt(singleRandomNumber));

     console.log("max", Math.max(2,3,4,5,55,6,8));
     console.log("min", Math.min(2,3,4,5,55,6,8));
     console.log("ceil", Math.ceil(4.5)); // round number above
     console.log("floor", Math.floor(4.5)); // round number below
     console.log("round", Math.round(4.2)); // normal round

	</script>
</html>













