<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>javascript Object</title>
</head>
<body>
	<script type="text/javascript">
		arr = ['a', 'b']
		console.log(arr[0]); //array

		obj = {'a':120, 'b':9}; //object
		console.log(obj);
		console.log(obj.a);
	</script>
</body>
</html>

//Regular expression
//Validation email and username and number